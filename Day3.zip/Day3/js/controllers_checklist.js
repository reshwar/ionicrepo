function ItemCtrl($scope, $http, $location) {

    $http.get('data/CheckListItems.json').success(function(data) {
       //
    $scope.items = data;
    }).error(function(data, status){alert(data+ " "+status)} );

 $location.path("/a");
 $scope.remaining = function() {
    var count = 0;

   	 angular.forEach($scope.items, function(item) {
   	if(item.done==false)
		count=count+1;
    	});

   return count;
  };  

$scope.addItem = function() {
    $scope.items.push({text:$scope.itemText, done:false});
    $scope.itemText = '';    };

}
