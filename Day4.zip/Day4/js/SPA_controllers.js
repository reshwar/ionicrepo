 var Site = angular.module('Site', []);
  function AppController($scope, $rootScope, $http) {  
    $http.get('data/pages.json').success(function(data) {
      $rootScope.pages = data;
      console.log(data.mobile);
    }) .error(function(data, status){alert(data+ " "+status);
    });
  }
Site.config(function($routeProvider) {
    $routeProvider.when('/page/:id', {
      templateUrl: 'partials/page.html',
      controller: 'RouteController'
    }).otherwise({
      redirectTo: '/page/mobile'
    });
  });
 function RouteController($scope, $rootScope, $routeParams) {
    // Getting the id from $routeParams
    var id = $routeParams.id;
    $scope.page = $rootScope.pages[id];
  }
