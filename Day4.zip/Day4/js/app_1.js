var bagApp = angular.module('bagApp', [
    'bagControllers'
    ]);
bagApp.config(['$routeProvider',
    function($routeProvider) {
        $routeProvider.
        when('/main', {
            templateUrl: 'Login',
            controller: 'LoginCtrl'
        }).
        when('/login', {
            templateUrl: 'Home'
        }).
 when('/viewbaglist', {
            templateUrl: 'partials/bag-list.html',
            controller: 'BagListCtrl'
        }).        
        when('/bags/:xyz', { 
            templateUrl: 'partials/bag-detail.html',
            controller: 'BagDetailCtrl'
        }).
        otherwise({
            redirectTo: '/main'
        });
    }]);
