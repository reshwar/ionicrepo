function getdir()
{
	alert("called");
}