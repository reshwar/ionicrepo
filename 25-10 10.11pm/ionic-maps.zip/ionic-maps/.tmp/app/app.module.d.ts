export declare class AppModule {
}
