import { Platform } from 'ionic-angular';
import { HomePage } from '../pages/home/home';
export declare class MyApp {
    rootPage: typeof HomePage;
    constructor(platform: Platform);
}
