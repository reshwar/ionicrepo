var directionsService;
var directionsDisplay;
var map;
var curlatlng;
var flag=0;
var x = 0;
window.onload = initMap;
function initMap() {
   directionsService = new google.maps.DirectionsService;
    directionsDisplay = new google.maps.DirectionsRenderer;
   map = new google.maps.Map(document.getElementById('map'), {
    zoom: 7,
    center: {lat: 17.385044, lng: 78.486671}
  });
  directionsDisplay.setMap(map);
 window.onload = initMap;
 showCurrentSource();

}

function showCurrentSource()
{
    if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showCurrentPosition);
    } else {
      alert("Geolocation is not supported by this browser.");
    }
}

//writes current location address to source input field 
function writeAddressName(latLng) {

        var geocoder = new google.maps.Geocoder();
        geocoder.geocode({
          "location": latLng
        },
        function(results, status) {
          if (status == google.maps.GeocoderStatus.OK)
          {
            
          document.getElementById('start').value = results[0].formatted_address;
          }
          else
          {
            
            alert("Unable to retrieve your address");
          }
        });
      }

function showCurrentPosition(position) {
 var userLatLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
        
        writeAddressName(userLatLng);
        var curlat = position.coords.latitude;
        var curlng = position.coords.longitude;  
        var uluru = {lat: curlat, lng: curlng};
        var marker = new google.maps.Marker({
          position: uluru,
          map: map,
          icon: {
                path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
                scale: 3
                }
        });
}

function getdir()
{ 
  getLocation(); 
}

function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
  } else {
    alert("Geolocation is not supported by this browser.");
  }
}

function showPosition(position) {
  var curlat = position.coords.latitude;
  var curlng = position.coords.longitude;
  curlatlng = curlat+","+curlng;
  curlatlng=String(curlatlng);
 var userLatLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
        writeAddressName(userLatLng);
  console.log("curlatlng"+curlatlng);
  var iconbase = '';
  console.log("lat-",curlat,",","lon-",curlng);
 var uluru = {lat: curlat, lng: curlng};
 var marker = new google.maps.Marker({
          position: uluru,
          map: map,
          icon: {
                path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
                scale: 3
                }
        });

 calculateAndDisplayRouteFromCurrentLoc(directionsService, directionsDisplay);

}

/*
function calculateAndDisplayRoute(directionsService, directionsDisplay) {
  console.log(document.getElementById('start').value); 
  directionsService.route({
    origin: document.getElementById('start').value,
    destination: document.getElementById('end').value,
    travelMode: 'DRIVING'
  }, function(response, status) {
    if (status === 'OK') {
      console.log("response:-",response);
      directionsDisplay.setDirections(response);
    } else {
      console.log(status);
    }
  });
}

*/

//generates path from source to destination via current location
function calculateAndDisplayRouteFromCurrentLoc(directionsService, directionsDisplay) {

  x =x +1;
  //To count number of intervals made
console.log("cnt- ",x);
  var waypts= [];
   waypts.push({
        location:curlatlng,
        stopover: false
      });
  directionsService.route({
    origin: document.getElementById('start').value,
    waypoints: waypts,
    destination: document.getElementById('end').value,
    travelMode: 'DRIVING'
  }, function(response, status) {
    if (status === 'OK') {
      console.log("response:-",response);
      directionsDisplay.setDirections(response);
    } else {
      console.log(status);

    }
  });

  if(flag==0)
  {
    flag=1;
    calInterval();
      
  }
}

//calls the function to regenerate the path 
function calInterval()
{
 
 setInterval(function(){ calculateAndDisplayRouteFromCurrentLoc(directionsService, directionsDisplay); }, 5000);
 
}

