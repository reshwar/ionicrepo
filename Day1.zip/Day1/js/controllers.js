
var bagApp = angular.module('bagApp', []);

bagApp.controller('BagListCtrl', function ($scope,$rootScope) {

  $scope.title = "Infy Shopping";
  
  $scope.bags = [
    {'name': 'Golden Ring Bag',
     'code': 'CODE:D-070',
     'age':10},
    {'name': 'Velvet Emb. Bag',
     'code': 'D-032',
     'age':5},
    {'name': 'AB-03 All Over Print Jute Bag',
     'code': 'D-108',
     'age':21}
  ];
  
  $scope.displayHello=function(name){

  	$scope.username=name;
  }
});







