import { NavController } from 'ionic-angular';
export declare class HomePage {
    navCtrl: NavController;
    constructor(navCtrl: NavController);
}
