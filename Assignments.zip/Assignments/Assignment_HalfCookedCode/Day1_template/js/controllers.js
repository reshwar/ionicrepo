//declare controller module

/*
 * declare LoginCtrl 
 * Code description for LoginCtrl:
        Method1:
            validate(user): validates entered username and password and alerts appropriate messages
 */

/*
 * declare BookListCtrl 
 * Code description for BookListCtrl:
        Hard code book details in json array and store this in a books model
 */
 
