//declare controller module

/*
 * declare LoginCtrl 
 * Code description for LoginCtrl:
        Method1:
            validate(user): 
            a. Need to validate entered username and password and alert appropriate messages
            b. cross verify against the roles inside roles.json file
             and associate the username to rootScope, if valid
            c. if username is set to rootScope , then display success message. 
                otherwise display error message.
                
            [ Hint: Use angular.forEach for iterations]
 */

/*
 * rename BookListCtrl  to BookListCtrl_Student
 * Code description for BookListCtrl_Student:
        Retrieve book details from books.json  and store this in a books model
 */


/*
 * declare BookListCtrl_Librarian
 * Code description for BookListCtrl_Librarian:
        Retrieve book details from books.json  and store this in a books model
 */


 
