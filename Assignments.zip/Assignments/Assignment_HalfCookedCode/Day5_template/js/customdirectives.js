// declare custom directive module

/*add custom directive 'highlight' with EA restiction
 * 
 * when you mouseover the element, 
 *  the element should be displayed in bold, italic and in red color.
 * when you mouseout,
 *  reset style to initial ones.
 */

/*add custom directive 'ngTopic' for custom validation
 * 
 * validate if the value supplied is 'AngularJS' or 'BackboneJS' or 'EmberJS' or 'NodeJS'.
 * if not, set validity to false.
 * else, set validity to true.
 */