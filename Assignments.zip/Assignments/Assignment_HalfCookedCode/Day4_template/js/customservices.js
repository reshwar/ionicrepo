//declare custom service module

//define custom service BookData
/*declare a function getData inside which you need to
 * make an ajax call to books.json and store the result.data to books model
 * inside rootScope.
 * 
 */