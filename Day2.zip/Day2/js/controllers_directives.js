 var app=angular.module('app',['controllers']);
 
    var controllers=angular.module('controllers',[]);
    
    controllers.controller('Ctrl', function($scope){

    $scope.footer="Copyright @ Infosys Limited";
    
    $scope.fun = function() {
   alert('chrvk')
  	 if($scope.mode=='VCR')
		{
		 $scope.courses = [
    			{coursename:'HTML', mode:'VCR'},
   			{coursename:'CSS', mode:'VCR'},
                        {coursename:'JS', mode:'VCR'}
			];
		}
	if($scope.mode=='CR')
		{
		 $scope.courses = [
    			{coursename:'AngularJS', mode:'CR'},
     			  {coursename:'BackboneJS', mode:'CR'}
			];
		}  

    };  
    $scope.save = function() {

    alert("Name:"+$scope.name+" Gender:"+$scope.gender+" Contact Number:"+$scope.contact+" Training Mode:"+$scope.mode+" CourseSelected:"+$scope.courseselected);

//coonect to server and store info inside the server

      };  

});