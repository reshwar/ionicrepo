function ItemCtrl($scope) {

 $scope.items = [
    {text:'Wheat Flour', done:true},
    {text:'Tooth Paste', done:false},
    {text:'Rice Flour', done:true},
    {text:'Talcum Powder', done:false},
    {textextt:'Ragi', done:true},
    {text:'Maida', done:false}
];

 
 $scope.remaining = function() {
    var count = 0;

   	 angular.forEach($scope.items, function(item) {
   	if(item.done==false)
		count=count+1;
    	});

   return count;
  };  

$scope.addItem = function() {
    $scope.items.push({text:$scope.itemText, done:false});
    $scope.itemText = '';    };

}
